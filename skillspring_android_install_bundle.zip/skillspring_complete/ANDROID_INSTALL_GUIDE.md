# Install SkillSpring on Android

SkillSpring is currently a Progressive Web App (PWA) prototype. It can be installed from Chrome after it is hosted on a secure HTTPS website. This is not an APK.

## Step 1 — Put the site online

1. Keep all files in this folder together: `index.html`, `manifest.webmanifest`, `sw.js`, and `icon.svg`.
2. Use a trusted static website host that supports HTTPS. A parent/guardian can help create and manage the hosting account if required by the service's age rules.
3. Upload the contents of this folder as the website's public files. The main page must be `index.html`.
4. Open the resulting HTTPS website address on your Android phone.

## Step 2 — Install from Chrome

1. Open the website in Google Chrome (not inside an in-app browser).
2. Tap Chrome's three-dot menu.
3. Choose **Install app** or **Add to Home screen**. The wording depends on the phone and Chrome version.
4. Confirm. SkillSpring should appear on the home screen and open in its own app-style window.

## Step 3 — Test it

- Open SkillSpring from the new home-screen icon.
- Try searching lessons, saving a lesson, and marking a lesson complete.
- Check that it still opens after closing Chrome. Offline support is best-effort and starts after the first successful online load.

## Important limitations

- Learner profile and progress are saved only in that browser/device; there is no cloud sync.
- The Plus option is a demonstration only. No payments are taken.
- Do not collect sensitive information from learners until secure accounts, privacy controls, and a proper backend are built.
- This install method does not publish the app on Google Play and does not create an APK.
- A Google Play release requires a separately built and signed Android package and a compliant Play Console account. A person under 18 must not misstate their age or bypass account requirements; an eligible adult must own/manage the developer account.
